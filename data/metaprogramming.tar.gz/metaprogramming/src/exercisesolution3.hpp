struct Print {
Print(std::stringstream& p_stream)
    : m_stream(p_stream) { }

template<typename T> void operator()(T, typename
 enable_if< is_base_of<Base, T> >::type* = 0) {
    m_stream << "B";
}
template<typename T> void operator()(T, typename
 disable_if< is_base_of<Base, T> >::type* = 0) {
    m_stream << "T";
}
std::stringstream& m_stream;
};

