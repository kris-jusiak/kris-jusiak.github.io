template<bool> class assert;
template<> class assert<true> { };

