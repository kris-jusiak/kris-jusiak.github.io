variadic templates:
    template<typename... T> class Vector {
        typedef sizeof...(T) size;
    };

template aliases:
    template<typename, typename=int> class A { };
    template<typename T>
    using AliasForA = A<T, int>;

extern templates:
    extern template class A<void>;

