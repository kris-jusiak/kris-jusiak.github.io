template<int Value = 0, typename T = void>
struct Print {
    unsigned : 80; //only in gcc
};

template<typename T> class A1
    : Print<__LINE__, T> // type size exceeded
{ };

template<typename T> class A2
    : boost::mpl::print<T> // sign comparison
{ };

