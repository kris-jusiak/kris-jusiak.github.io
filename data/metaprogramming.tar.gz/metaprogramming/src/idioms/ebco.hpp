class Empty {
    typedef int type;
}; //sizeof(Empty) == 1

class Empty2 : public empty { }; //sizeof(Empty) == 1

