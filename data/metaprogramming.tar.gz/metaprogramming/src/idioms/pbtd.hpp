template<
    typename Policy1 = DefaultPolicy1,
    typename Policy2 = DefaultPolicy2,
    typename Policy3 = DefaultPolicy3
>
class ClassWithPolicies { };

ClassWithPolicies<> l_classWithPolicies;
ClassWithPolicies<MyPolicy1> l_classWithPolicies;
ClassWithPolicies<MyPolicy1, MyPolicy2> l_classWithPolicies;

