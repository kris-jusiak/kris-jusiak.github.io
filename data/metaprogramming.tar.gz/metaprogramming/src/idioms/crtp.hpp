template<typename Derived>
class Base
{
public:
    void func() {
        static_cast<Derived*>(this)->impl();
    }
};

struct A { void impl() { } };

struct B { void impl() { } };

