template<typename T> class is_class {
    template<typename C>
    static yes test(int C::*);

    template<typename C>
    static no test(...);

public:
    static const bool value =
        sizeof(test<T>(0) == sizeof(yes));
};

