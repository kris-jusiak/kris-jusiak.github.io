namespace Detail {
    class TDependecies { typedef F f; };

    template
    <
        typename T,
        typename Dependecies = TDependecies
    >
    class Yac { };
} // namespace Detail

template<typename T> struct Yac {
    typedef Detail::Yac<T> type;
};
