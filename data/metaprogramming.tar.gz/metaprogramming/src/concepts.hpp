template<typename T>
Concept Simple {
    typedef T::type type;
    void func();
};

template<Simple T> class A1 { };
//or
template<typename T> requires<T, Simple>
class A2 { };
