class Base { };
class T1 : Base { };
class T2 { };
class T3 : Base { };

TEST(Exercise, Basic) {
    //given
    typedef boost::mpl::vector<T1, T2, T3> types;
    std::stringstream l_stream;
    //when
    forEach<types>(Print(l_stream));
    //then
    EXPECT_EQ("BTB", l_stream.str());
}

