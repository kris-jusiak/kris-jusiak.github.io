#define GENERATE_VECTOR(z, n, void_type)
BOOST_PP_COMMA_IF(n) typename T##n = void_type

#define GENERATE_VECTOR_TYPES(z, n, not_used)
BOOST_PP_COMMA_IF(n) typedef T##n type##n;

template
<BOOST_PP_REPEAT(10, GENRATE_VECTOR, none)>
struct Vector {
    BOOST_PP_REPEAT(10, GENRATE_VECTOR_TYPES, ~)
};

