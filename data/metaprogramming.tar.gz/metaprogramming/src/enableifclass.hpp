template<typename, typename Enable = void>
struct A { } {
    typedef int type;
}

template<typename T>
struct A<T, typename enable_if< is_base_of<Base, T>::type> > {
    typedef double type;
};

