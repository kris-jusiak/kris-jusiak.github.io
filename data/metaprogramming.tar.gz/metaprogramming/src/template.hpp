struct A {
    template<typename T> static void func() { }
};

template<typename T> class B1 {
    B1() {
        T::func<int>(); //ERROR
    }
};
template<typename T> class B2 {
    B2() {
        T::template func<int>(); //OK
    }
};
