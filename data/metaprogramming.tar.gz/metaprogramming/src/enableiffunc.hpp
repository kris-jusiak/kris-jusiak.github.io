template<typename Seq, typename F>
void forEach(F,
 typename enable_if< empty<Seq> >::type* = 0)
{ }

template<typename Seq, typename F>
void forEach(F p_f,
 typename disable_if< empty<Seq> >::type* = 0)
{
    typedef typename front<Seq>::type front;
    p_f.template operator()<front>();
    forEach<typename pop_front<Seq>::type>(p_f);
}

