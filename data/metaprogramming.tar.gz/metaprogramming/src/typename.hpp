template<typename T>
class A1 {
    typedef T::type type; //ERROR
};

template<typename T>
class A2 {
    typedef typename T::type type; //OK
};

