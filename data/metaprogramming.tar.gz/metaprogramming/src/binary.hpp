template<unsigned N>
struct binary {
    static const unsigned value = binary<N/10>::value * 2 + N%10;
};

template<>
struct binary<0> {
    static const unsigned value = 0;
};

std::clog << binary<100>::value;
// (((0) * 2 + 1) * 2 + 0) * 2 + 0 = 4

